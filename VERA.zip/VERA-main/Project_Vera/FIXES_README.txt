VERA MODULE FIXES
=================

Patched modules:
- summary.py: removed the hard-coded placeholder OpenAI key and mandatory OpenAI/requests-html imports. It now extracts article text with newspaper3k and a requests/BeautifulSoup fallback, then generates an extractive summary locally.
- falseNewsChecker.py: removed unused SentenceTransformer and GoogleNews dependencies. Related coverage is retrieved from Google News RSS; unavailable matching coverage is reported as UNVERIFIABLE, not automatically fake.
- story_clusterer_semantic.py: added the module that app.py was trying to import. It clusters submitted article text with TF-IDF + DBSCAN and returns HTML.

IMPORTANT:
1. Open a terminal in Project_Vera.
2. Activate your virtual environment.
3. Run: python -m pip install -r requirements.txt
4. Run: python app.py
5. Open: http://127.0.0.1:5000

Use article URLs for the summarizer and fake-news checker. For clustering, paste at least two article texts separated by a blank line.

The fake-news checker is a corroboration aid, not a definitive truth detector. Text similarity and lack of matching coverage cannot establish whether a claim is true or false.
