"""News corroboration checker using Google News RSS and TF-IDF similarity.
This is a source-comparison aid, not a definitive fact-checking authority.
"""
import re
import requests
import xml.etree.ElementTree as ET
from newspaper import Article
from bs4 import BeautifulSoup
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class FalseNewsChecker:
    def extract_article(self, url):
        try:
            article = Article(url)
            article.download()
            article.parse()
            if article.text and len(article.text.strip()) > 100:
                return article.text.strip()
        except Exception:
            pass
        try:
            response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=12)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, "html.parser")
            return " ".join(p.get_text(" ", strip=True) for p in soup.find_all("p"))
        except Exception:
            return ""

    def fetch_related_news(self, query, max_results=10):
        try:
            url = "https://news.google.com/rss/search"
            response = requests.get(url, params={"q": query, "hl": "en-IN", "gl": "IN", "ceid": "IN:en"},
                                    headers={"User-Agent": "Mozilla/5.0"}, timeout=12)
            response.raise_for_status()
            root = ET.fromstring(response.content)
            entries = root.findall(".//item")
            results = []
            for item in entries[:max_results]:
                source = item.findtext("source") or ""
                results.append({"title": item.findtext("title") or "",
                                "link": item.findtext("link") or "", "media": source})
            return results
        except Exception:
            return []

    def check(self, input_url_or_text):
        value = (input_url_or_text or "").strip()
        input_text = self.extract_article(value) if value.startswith(("http://", "https://")) else value
        if len(input_text.split()) < 10:
            return {"error": "Could not extract enough article text.", "verdict": "UNVERIFIABLE",
                    "reliability_score": None, "related_articles": [], "snippets": []}

        # Search with a concise query rather than the first ten arbitrary words.
        words = re.findall(r"\b[A-Za-z]{4,}\b", input_text)
        query = " ".join(words[:12])
        related = self.fetch_related_news(query)
        related_texts, related_clean = [], []
        for item in related:
            link = item.get("link", "")
            if not link:
                continue
            txt = self.extract_article(link)
            if len(txt.split()) >= 10:
                related_texts.append(txt)
                related_clean.append({"title": item.get("title", ""), "link": link,
                                      "media": item.get("media", "")})

        if not related_texts:
            return {"max_similarity": 0, "avg_similarity": 0, "reliability_score": None,
                    "verdict": "UNVERIFIABLE — no comparable coverage found",
                    "related_articles": related_clean, "snippets": [],
                    "note": "Lack of matching coverage does not prove a story is fake."}

        try:
            vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), max_features=12000)
            matrix = vectorizer.fit_transform([input_text] + related_texts)
            sims = cosine_similarity(matrix[0:1], matrix[1:]).ravel()
        except ValueError:
            sims = []
        if len(sims) == 0:
            return {"verdict": "UNVERIFIABLE", "reliability_score": None,
                    "related_articles": related_clean, "snippets": []}

        max_sim, avg_sim = float(sims.max()), float(sims.mean())
        score = round(max_sim * 100, 2)
        if max_sim >= 0.25:
            verdict = "CORROBORATED — similar reporting found"
        elif max_sim >= 0.10:
            verdict = "PARTIALLY CORROBORATED — review sources"
        else:
            verdict = "UNVERIFIABLE — little matching coverage found"

        snippets = [{"title": related_clean[i]["title"],
                     "snippet": " ".join(re.findall(r"\w+", related_texts[i])[:24]) + "..."}
                    for i in range(min(3, len(related_texts)))]
        return {"max_similarity": round(max_sim, 3), "avg_similarity": round(avg_sim, 3),
                "reliability_score": score, "verdict": verdict,
                "related_articles": related_clean, "snippets": snippets,
                "note": "Similarity measures textual overlap, not factual truth. Verify claims against primary sources."}
