"""Article extraction and offline extractive summarization for Project VERA."""
import re
import requests
from bs4 import BeautifulSoup
from newspaper import Article

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"

def extract_article(url):
    if not url or not url.startswith(("http://", "https://")):
        raise ValueError("Please provide a valid http/https article URL.")

    # newspaper3k first
    try:
        article = Article(url, language="en")
        article.download()
        article.parse()
        title = article.title or ""
        text = article.text or ""
        if len(text.strip()) >= 200:
            return title, text
    except Exception:
        pass

    # requests + BeautifulSoup fallback
    response = requests.get(url, headers={"User-Agent": UA}, timeout=15)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    title = ""
    og = soup.find("meta", property="og:title")
    if og:
        title = og.get("content", "")
    elif soup.title:
        title = soup.title.get_text(" ", strip=True)
    for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
        tag.decompose()
    article_node = soup.find("article") or soup
    text = " ".join(p.get_text(" ", strip=True) for p in article_node.find_all("p"))
    if len(text.strip()) < 200:
        raise ValueError("Could not extract enough article text. The website may block automated access.")
    return title, text

def _sentences(text):
    text = re.sub(r"\s+", " ", text).strip()
    return [x.strip() for x in re.split(r"(?<=[.!?])\s+", text) if len(x.strip().split()) >= 5]

def smart_summarize(url):
    title, text = extract_article(url)
    sentences = _sentences(text)
    if not sentences:
        raise ValueError("The article did not contain enough readable sentences.")

    # Rank sentences by word frequency; no API key or paid service required.
    words = re.findall(r"\b[a-zA-Z]{3,}\b", text.lower())
    stop = {"the","and","for","that","with","this","from","are","was","were","has","have","had","but","not","you","its","into","about","after","before","their","they","will","would","could","also","said"}
    freq = {}
    for word in words:
        if word not in stop:
            freq[word] = freq.get(word, 0) + 1
    ranked = []
    for i, sentence in enumerate(sentences):
        terms = [w for w in re.findall(r"\b[a-zA-Z]{3,}\b", sentence.lower()) if w not in stop]
        score = sum(freq.get(w, 0) for w in terms) / max(1, len(terms))
        ranked.append((score, i, sentence))
    count = min(6, max(3, len(sentences)//8))
    chosen = sorted(sorted(ranked, reverse=True)[:count], key=lambda x: x[1])
    summary = "\n".join("• " + item[2] for item in chosen)
    return summary
