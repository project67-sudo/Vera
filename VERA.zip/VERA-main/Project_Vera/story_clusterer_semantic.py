"""Lightweight TF-IDF article clustering for the Flask /api/cluster endpoint."""
from html import escape
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import DBSCAN

def cluster_articles(articles):
    articles = [str(x).strip() for x in articles if str(x).strip()]
    if len(articles) < 2:
        return "<p>At least 2 non-empty articles are required.</p>"
    try:
        vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), max_df=1.0)
        matrix = vectorizer.fit_transform(articles)
        # Cosine distance: related articles are grouped; unrelated stories remain noise.
        labels = DBSCAN(eps=0.68, min_samples=2, metric="cosine").fit_predict(matrix)
    except ValueError:
        return "<p>Articles contain too little distinct text to cluster. Please provide longer articles.</p>"

    groups = {}
    for text, label in zip(articles, labels):
        groups.setdefault(int(label), []).append(text)

    ordered = sorted((k for k in groups if k != -1), key=lambda k: len(groups[k]), reverse=True)
    html = ["<div class='story-clusters'><h2>Story Clustering Results</h2>"]
    for number, label in enumerate(ordered, 1):
        items = groups[label]
        html.append(f"<section style='background:#1e1e1e;padding:16px;border-radius:12px;margin:12px 0;border-left:4px solid #4caf50'>")
        html.append(f"<h3>Story Group {number} ({len(items)} articles)</h3>")
        for item in items:
            html.append(f"<p>{escape(item[:500])}{'...' if len(item)>500 else ''}</p>")
        html.append("</section>")
    noise = groups.get(-1, [])
    if noise:
        html.append(f"<section style='background:#1e1e1e;padding:16px;border-radius:12px;margin:12px 0;border-left:4px solid #f59e0b'><h3>Unique / Unmatched ({len(noise)} articles)</h3>")
        for item in noise:
            html.append(f"<p>{escape(item[:500])}{'...' if len(item)>500 else ''}</p>")
        html.append("</section>")
    html.append("</div>")
    return "".join(html)
